<?php

$lang['blog'] = base_url('blog');
$lang['post_details'] = base_url('blog/post_details/');
$lang['assets'] = base_url('assets/home/');
$lang['post_img'] = base_url('uploads/images/post/');
$lang['post_img_thumb'] = base_url('uploads/images/post/thumb/');